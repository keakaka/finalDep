var https = require('https'),
    express = require('express'),
    fs = require('fs');
io = require('socket.io')(https);

var options = {
    key: fs.readFileSync('key.pem'),
    cert: fs.readFileSync('cert.pem')
};

var port2 = 3000;

var app = express();

var server = https.createServer(options, app).listen(port2, function(){
  console.log("Https server listening on port " + port2);
});

app.use('',function(req, res){  //2
  res.sendFile(__dirname + '/client.html');
});


var count=1;

io.listen(server, { log: false }).on('connection', function(socket){ //3
  console.log('user connected: ', io.id);  //3-1
  var name = 'user'+count++;
  console.log(name);                 //3-1
  socket.emit('change name',name);
  console.log(name);   //3-1

  socket.on('disconnect', function(){ //3-2
    console.log('user disconnected: ', io.id);
  });

  socket.on('send message', function(name,text){ //3-3
    var msg = name + ' : ' + text;
    console.log(msg);
    io.emit('receive message', msg);
  });
});
