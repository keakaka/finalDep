AngularJS WebRTC
================

Demo project for my [blog post](http://blog.mgechev.com/2014/12/26/multi-user-video-conference-webrtc-angularjs-yeoman/).
